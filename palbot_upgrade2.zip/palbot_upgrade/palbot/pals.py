PALS=['Lamball','Cattiva','Chikipi','Vixy','Foxsparks','Pengullet','Sparkit','Lifmunk','Vanwyrm','Dazzi']
