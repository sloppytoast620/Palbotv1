import sqlite3
import time
from typing import List, Tuple

DB_PATH = "palbot.db"

def _connect():
    return sqlite3.connect(DB_PATH)

def init_db():
    with _connect() as con:
        cur = con.cursor()
        cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            coins INTEGER NOT NULL DEFAULT 0,
            catches INTEGER NOT NULL DEFAULT 0,
            last_catch_ts INTEGER NOT NULL DEFAULT 0
        )
        """)
        cur.execute("""
        CREATE TABLE IF NOT EXISTS owned_pals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            pal_id TEXT NOT NULL,
            pal_name TEXT NOT NULL,
            rarity TEXT NOT NULL,
            element TEXT NOT NULL,
            caught_ts INTEGER NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(user_id)
        )
        """)
        con.commit()

def ensure_user(user_id: int):
    with _connect() as con:
        cur = con.cursor()
        cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
        con.commit()

def get_user(user_id: int) -> Tuple[int, int, int]:
    """returns (coins, catches, last_catch_ts)"""
    ensure_user(user_id)
    with _connect() as con:
        cur = con.cursor()
        cur.execute("SELECT coins, catches, last_catch_ts FROM users WHERE user_id = ?", (user_id,))
        row = cur.fetchone()
        return (row[0], row[1], row[2]) if row else (0, 0, 0)

def set_last_catch(user_id: int, ts: int):
    ensure_user(user_id)
    with _connect() as con:
        cur = con.cursor()
        cur.execute("UPDATE users SET last_catch_ts = ? WHERE user_id = ?", (ts, user_id))
        con.commit()

def add_catch(user_id: int, pal_id: str, pal_name: str, rarity: str, element: str):
    ensure_user(user_id)
    now = int(time.time())
    with _connect() as con:
        cur = con.cursor()
        cur.execute("""
            INSERT INTO owned_pals (user_id, pal_id, pal_name, rarity, element, caught_ts)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (user_id, pal_id, pal_name, rarity, element, now))
        cur.execute("UPDATE users SET catches = catches + 1 WHERE user_id = ?", (user_id,))
        con.commit()

def list_owned(user_id: int) -> List[Tuple[int, str, str, str]]:
    """returns list of (owned_id, pal_name, rarity, element)"""
    ensure_user(user_id)
    with _connect() as con:
        cur = con.cursor()
        cur.execute("""
            SELECT id, pal_name, rarity, element
            FROM owned_pals
            WHERE user_id = ?
            ORDER BY id DESC
        """, (user_id,))
        return cur.fetchall()

def count_owned(user_id: int) -> int:
    ensure_user(user_id)
    with _connect() as con:
        cur = con.cursor()
        cur.execute("SELECT COUNT(*) FROM owned_pals WHERE user_id = ?", (user_id,))
        return int(cur.fetchone()[0])

def release_owned(user_id: int, owned_id: int) -> bool:
    ensure_user(user_id)
    with _connect() as con:
        cur = con.cursor()
        cur.execute("DELETE FROM owned_pals WHERE user_id = ? AND id = ?", (user_id, owned_id))
        deleted = cur.rowcount
        con.commit()
        return deleted > 0
