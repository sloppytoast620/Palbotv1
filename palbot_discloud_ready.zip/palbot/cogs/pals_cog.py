import time
import random
import discord
from discord.ext import commands
from discord import app_commands

from palbot.pals import PALS, weighted_random_pal
from palbot import storage

CATCH_COOLDOWN_SECONDS = 30

class PalsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    pal_group = app_commands.Group(name="pal", description="Pal commands")

    @pal_group.command(name="random", description="See a random Pal")
    async def pal_random(self, interaction: discord.Interaction):
        pal = weighted_random_pal()
        embed = discord.Embed(
            title=f"🧩 {pal.name}",
            description=f"Element: **{pal.element}**\nRarity: **{pal.rarity}**",
        )
        embed.set_footer(text=f"Catch chance base: {int(pal.base_catch * 100)}%")
        await interaction.response.send_message(embed=embed)

    @pal_group.command(name="list", description="List all Pals in the bot database")
    async def pal_list(self, interaction: discord.Interaction):
        lines = [f"• **{p.name}** — {p.element} — {p.rarity}" for p in PALS]
        msg = "\n".join(lines[:40])
        if len(lines) > 40:
            msg += f"\n…and {len(lines)-40} more."
        await interaction.response.send_message(msg)

    @app_commands.command(name="catch", description="Try to catch a Pal (30s cooldown)")
    async def catch(self, interaction: discord.Interaction):
        user_id = interaction.user.id
        storage.ensure_user(user_id)
        coins, catches, last_ts = storage.get_user(user_id)

        now = int(time.time())
        remaining = (last_ts + CATCH_COOLDOWN_SECONDS) - now
        if remaining > 0:
            await interaction.response.send_message(
                f"⏳ You need to wait **{remaining}s** before catching again.",
                ephemeral=True
            )
            return

        pal = weighted_random_pal()

        # Rarity tweak (simple)
        rarity_bonus = {
            "Common": 0.10,
            "Uncommon": 0.05,
            "Rare": 0.00,
            "Epic": -0.03,
            "Legendary": -0.08,
        }.get(pal.rarity, 0.0)

        chance = max(0.05, min(0.90, pal.base_catch + rarity_bonus))
        roll = random.random()

        storage.set_last_catch(user_id, now)

        if roll <= chance:
            storage.add_catch(user_id, pal.id, pal.name, pal.rarity, pal.element)
            owned_count = storage.count_owned(user_id)
            await interaction.response.send_message(
                f"✅ You caught **{pal.name}**! ({pal.rarity}, {pal.element})\n"
                f"📦 Total owned: **{owned_count}**"
            )
        else:
            await interaction.response.send_message(
                f"❌ **{pal.name}** escaped! (Chance was {int(chance*100)}%)"
            )

    @app_commands.command(name="profile", description="View your Palbot profile")
    async def profile(self, interaction: discord.Interaction):
        user_id = interaction.user.id
        coins, catches, last_ts = storage.get_user(user_id)
        owned = storage.count_owned(user_id)

        embed = discord.Embed(title=f"👤 {interaction.user.display_name}'s Profile")
        embed.add_field(name="Pals Owned", value=str(owned), inline=True)
        embed.add_field(name="Total Catches", value=str(catches), inline=True)
        embed.add_field(name="Coins", value=str(coins), inline=True)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="inventory", description="List your owned Pals")
    async def inventory(self, interaction: discord.Interaction):
        user_id = interaction.user.id
        rows = storage.list_owned(user_id)
        if not rows:
            await interaction.response.send_message("📦 Your inventory is empty. Use `/catch` to get a Pal!")
            return

        lines = []
        for owned_id, name, rarity, element in rows[:20]:
            lines.append(f"`{owned_id}` • **{name}** — {rarity} — {element}")
        msg = "\n".join(lines)
        if len(rows) > 20:
            msg += f"\n…and {len(rows)-20} more."

        await interaction.response.send_message(msg)

    @app_commands.command(name="release", description="Release a Pal you own by its inventory ID")
    @app_commands.describe(inventory_id="The ID shown in /inventory (e.g. 12)")
    async def release(self, interaction: discord.Interaction, inventory_id: int):
        user_id = interaction.user.id
        ok = storage.release_owned(user_id, inventory_id)
        if ok:
            await interaction.response.send_message(f"🗑️ Released Pal with inventory ID `{inventory_id}`.")
        else:
            await interaction.response.send_message(
                f"⚠️ I couldn't find a Pal with inventory ID `{inventory_id}` that you own.",
                ephemeral=True
            )

async def setup(bot: commands.Bot):
    await bot.add_cog(PalsCog(bot))
