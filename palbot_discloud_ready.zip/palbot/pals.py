from dataclasses import dataclass
from typing import List
import random

@dataclass(frozen=True)
class Pal:
    id: str
    name: str
    element: str
    rarity: str
    base_catch: float  # 0.0 - 1.0

# Simple starter roster (expand anytime)
PALS: List[Pal] = [
    Pal("lamball", "Lamball", "Neutral", "Common", 0.55),
    Pal("cattiva", "Cattiva", "Neutral", "Common", 0.50),
    Pal("pengullet", "Pengullet", "Water", "Common", 0.45),
    Pal("foxsparks", "Foxsparks", "Fire", "Uncommon", 0.35),
    Pal("sparkit", "Sparkit", "Electric", "Uncommon", 0.33),
    Pal("ribunny", "Ribunny", "Neutral", "Uncommon", 0.30),
    Pal("vanwyrm", "Vanwyrm", "Dark", "Rare", 0.18),
    Pal("ragnahawk", "Ragnahawk", "Fire", "Epic", 0.10),
]

RARITY_WEIGHT = {
    "Common": 60,
    "Uncommon": 25,
    "Rare": 10,
    "Epic": 4,
    "Legendary": 1,
}

def weighted_random_pal() -> Pal:
    # Weight by rarity to make commons appear more often
    weights = [RARITY_WEIGHT.get(p.rarity, 10) for p in PALS]
    return random.choices(PALS, weights=weights, k=1)[0]

def find_pal_by_id(pal_id: str) -> Pal | None:
    pal_id = pal_id.lower().strip()
    for p in PALS:
        if p.id == pal_id:
            return p
    return None
